A super simple python module that hits the NHTSA api and decodes a given list of VINs to output strings.

Usage:

>>>from vin_decoder import VinDecoder<br>
>>>VinDecoder(**My_list_of_VINs**)
